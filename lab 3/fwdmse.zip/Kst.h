#import <Foundation/Foundation.h >
#import "TaxProto.h"

@interface Kst:NSObject <TaxProto>

-(float)CalTax:(int)amt;

@end
