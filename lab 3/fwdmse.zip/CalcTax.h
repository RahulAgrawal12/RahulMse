#import <Foundation/Foundation.h>
#import "Bill.h"

@interface CalcTax:NSObject

-(void)CalcTaxonBill:(Bill*) bill;

@end
