#import <Foundation/Foundation.h>

@protocol TaxProto

-(float)CalTax:(int)amt;

@end